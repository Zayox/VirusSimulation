import './css/App.css';
import ChartC from "./components/Chart";
import './css/App.css';
import Mater from "./components/Matter";


function App() {
  return (
    <div className="App">
        <ChartC />
        <Mater className="mater" />
    </div>

  );
}

export default App;
